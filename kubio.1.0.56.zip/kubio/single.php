<?php get_header(); ?>
<?php kubio_theme()->get( 'single' )->render(); ?>
<?php
get_footer();
