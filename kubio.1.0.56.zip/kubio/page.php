<?php get_header(); ?>
<?php kubio_theme()->get( 'content' )->render(); ?>
<?php
get_footer();
