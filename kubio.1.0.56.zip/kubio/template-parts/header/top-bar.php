<div class="wp-block wp-block-kubio-navigation-top-bar  kubio-hide-on-mobile position-relative wp-block-kubio-navigation-top-bar__outer kubio-header__k__b2YVMldxUMm-outer kubio-local-453-outer d-flex align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/navigation-top-bar">
	<div class="background-wrapper">
		<div class="background-layer background-layer-media-container-lg"></div>
		<div class="background-layer background-layer-media-container-md"></div>
		<div class="background-layer background-layer-media-container"></div>
	</div>
	<div class="position-relative wp-block-kubio-navigation-top-bar__inner kubio-header__k__b2YVMldxUMm-inner kubio-local-453-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container kubio-header__k__LchI5z_G-ql-container kubio-local-454-container gutters-row-lg-0 gutters-row-v-lg-0 gutters-row-md-0 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/row">
			<div class="background-wrapper">
				<div class="background-layer background-layer-media-container-lg"></div>
				<div class="background-layer background-layer-media-container-md"></div>
				<div class="background-layer background-layer-media-container"></div>
			</div>
			<div class="position-relative wp-block-kubio-row__inner kubio-header__k__LchI5z_G-ql-inner kubio-local-454-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-0 gutters-col-md-0 gutters-col-v-md-0 gutters-col-0 gutters-col-v-0">
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container kubio-header__k__ltBLs1jKCt_-container kubio-local-455-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner kubio-header__k__ltBLs1jKCt_-inner kubio-local-455-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align kubio-header__k__ltBLs1jKCt_-align kubio-local-455-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php kubio_theme()->get('top-bar-list-icons')->render(); ?>
						</div>
					</div>
				</div>
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container kubio-header__k__kvhfjD7jyyb-container kubio-local-463-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner kubio-header__k__kvhfjD7jyyb-inner kubio-local-463-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align kubio-header__k__kvhfjD7jyyb-align kubio-local-463-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php kubio_theme()->get('top-bar-social-icons')->render(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
