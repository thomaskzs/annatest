<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<h1 class="wp-block wp-block-kubio-heading  position-relative wp-block-kubio-heading__text kubio-front-header__k__ukjZtaF3MN-text kubio-local-678-text" data-kubio="kubio/heading">
	<?php $component->printTitle(); ?>
</h1>
