<span class="wp-block wp-block-kubio-button  position-relative wp-block-kubio-button__outer kubio-front-header__k__Dud6AOZG0Hc-outer kubio-local-682-outer kubio-button-container" data-kubio="kubio/button">
	<a class="position-relative wp-block-kubio-button__link kubio-front-header__k__Dud6AOZG0Hc-link kubio-local-682-link h-w-100 h-global-transition" href="<?php echo esc_url(\ColibriWP\Theme\View::getData('url')); ?>">
		<span class="position-relative wp-block-kubio-button__text kubio-front-header__k__Dud6AOZG0Hc-text kubio-local-682-text kubio-inherit-typography">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('label')); ?>
		</span>
	</a>
</span>
